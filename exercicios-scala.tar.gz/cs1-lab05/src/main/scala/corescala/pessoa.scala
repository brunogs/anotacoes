package corescala

abstract class Pessoa(var nome: String) {
  def numDocumento: String
}

class PessoaFisica(nome: String, cpf: String) extends Pessoa(nome) {
	override def numDocumento: String = cpf
}
class PessoaJuridica(nome: String, cnpj: String) extends Pessoa(nome) {
	override def numDocumento: String = cnpj
}

object CriadorPessoas {
	
	def criarPF(nome:String, cpf: String): Pessoa = new PessoaFisica(nome, cpf)
	def criarPJ(nome:String, cnpj: String): Pessoa = new PessoaFisica(nome, cnpj)

}
