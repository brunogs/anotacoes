package corescala

import scala.xml.NodeSeq

class Container(app: WebApp) {

  implicit val request = new Request(1)

  def run(page: String): String = page match {
    case "index" => app.index
    case "about" => app.about
    case "contato" => app.contato
    case p => "pagina desconhecida"
  }
}

object Container {
   implicit def strToNodeSeq(value: String): NodeSeq = {
	<html>
	   <body>{value}</body>
	</html>
   }
}
