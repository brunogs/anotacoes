# --- !Ups

CREATE SEQUENCE participante_seq;
CREATE TABLE participante (
	id INTEGER NOT NULL DEFAULT nextval('participante_seq'),
	nome VARCHAR(500) NOT NULL,
	email VARCHAR(255) NOT NULL
);


# --- !Downs
DROP TABLE participante;
DROP SEQUENCE participante_seq;
