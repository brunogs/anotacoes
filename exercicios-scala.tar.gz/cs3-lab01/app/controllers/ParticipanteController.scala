package controllers

import javax.inject._
import play.api._
import play.api.mvc._
import play.api.data._
import play.api.data.Forms._
import models._

@Singleton
class ParticipanteController extends Controller {

  val formParticipante = Form {
     mapping ( "nome" -> nonEmptyText, "email" -> email ) (Participante.apply) (Participante.unapply)
  }

  def listarParticipantes = Action {
    println("vai tentar listar")
    Ok( views.html.participantes(Participante.listar) )
  }

  def novoParticipante = Action {
    Ok( views.html.newParticipante(formParticipante) )
  }

  def salvarParticipante = Action { implicit request =>
    formParticipante.bindFromRequest.fold(
       errors => BadRequest(views.html.newParticipante(errors)),
       participante => {
	 println("vai tentar salvar")
	 Participante.salvar(participante)
         Redirect(routes.ParticipanteController.listarParticipantes)
       }
    )
  }



  def visitas = Action { implicit request =>
    val visitas = request.session.get("visitas").map(_.toInt + 1).getOrElse(1)

    Ok(s"Quantidade de visitas: ${visitas}")
		.addingToSession("visitas" -> visitas.toString)
  }

}
