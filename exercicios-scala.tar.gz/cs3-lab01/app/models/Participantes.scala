package models

import play.api.db._
import play.api.Play.current
import anorm._
import anorm.SqlParser._
import scala.language.postfixOps

case class Participante (nome: String, email: String) {
   override def toString = nome
}

object Participante {

  val participanteParser = str("nome") ~ str("email") map {
     case nome~email => Participante(nome, email)
  }

  def salvar(p: Participante) = {
    DB.withConnection { implicit conn =>
       SQL"INSERT INTO participante(nome, email) VALUES (${p.nome}, ${p.email})".executeUpdate()
    }
  }

  def listar: Seq[Participante] = {
    DB.withConnection { implicit conn =>
       SQL"SELECT * FROM participante".as(participanteParser *)
    }
  }
}
