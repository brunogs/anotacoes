import scala.concurrent.duration._
import akka.actor._
import akka.routing._
import java.util.concurrent.TimeoutException
import java.net.UnknownHostException
import akka.actor.SupervisorStrategy._
import akka.actor.OneForOneStrategy

case class Participante(nome: String, email: String) {
   override def toString: String = nome
}

case class GetParticipantes()

case class EnviarEmail(emailDestino: String, mensagem: String)


class ColetorParticipantes extends Actor {
   var participantes: Seq[Participante] = Seq()
   //val enviador = context.actorOf(Props[EnviadorEmails])
   val enviador = context.actorOf(RandomPool(5).props(Props[EnviadorEmails]), "roteador_enviador")

   override val supervisorStrategy = OneForOneStrategy(maxNrOfRetries = 10, withinTimeRange = 1 minute) {
	case _: TimeoutException => Resume
	case _: UnknownHostException => Restart
   }

   def receive = {
	case p: Participante => { 
	  participantes = participantes :+ p
	  enviador ! EnviarEmail(p.email, s"Ei ${p.nome} você é um participante da nova reunião")
	}
	case GetParticipantes => sender ! participantes
   }
}



class ColetorParticipantesConfig extends Actor {
   var participantes: Seq[Participante] = Seq()
   val enviador = context.actorOf(FromConfig.props(Props[EnviadorEmails]), "enviadorEmails")  
   def receive = {
	case p: Participante => { 
	  participantes = participantes :+ p
	  enviador ! EnviarEmail(p.email, s"Ei ${p.nome} você é um participante da nova reunião")
	}
   }
}




class EnviadorEmails extends Actor {
   override def preStart = println("Actor EnviadorEmail inciado!!!")

   def receive = {
	/*
	case EnviarEmail(emailDestino, _) if emailDestino == "timeout" => throw new TimeoutException("Acabo o tempo")
	case EnviarEmail(emailDestino, _) if emailDestino == "desconhecido" => throw new UnknownHostException("Desconhecido, não passara")
	*/
	case msg: EnviarEmail => println(s"${self.path}  Mensagem para: ${msg.emailDestino}\nConteudo: ${msg.mensagem} ")
   }
}
