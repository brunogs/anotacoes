import akka.actor._
import akka.pattern.ask
import akka.util.Timeout
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global

object SistemaColetor extends App {

	implicit val timeout = Timeout(5 seconds)
	val system = ActorSystem("corescala-reuniao")
	val coletor = system.actorOf(Props[ColetorParticipantes])
	val coletorConfig = system.actorOf(Props[ColetorParticipantesConfig], "coletorConfig")

	
	coletorConfig ! Participante("Cris", "cris@email.com")
	coletorConfig ! Participante("Joãozinho", "joaozinho@email.com")
	coletorConfig ! Participante("Biaginho", "biaginho@email.com")
	coletorConfig ! Participante("Frank", "frank@email.com")
	coletorConfig ! Participante("Elton", "elton@email.com")

/*
	coletor ! Participante("Cris", "cris@email.com")
	coletor ! Participante("Joãozinho", "joaozinho@email.com")
	coletor ! Participante("Biaginho", "biaginho@email.com")
	coletor ! Participante("Frank", "frank@email.com")
	coletor ! Participante("Elton", "elton@email.com")
	coletor ! Participante("Veio", "veio@email.com")
	coletor ! Participante("timeout", "timeout") //timeout
	coletor ! Participante("Bruno", "bruno@email.com")
	coletor ! Participante("desconhecido", "desconhecido") //desconhecido
	coletor ! Participante("Bruno123", "bruno@email.com")
*/


	/*
	val participantesFinais = coletor ? GetParticipantes

	participantesFinais.onSuccess {
		case msg: Seq[_] => msg.foreach(println)
	}
	*/

	Thread.sleep(5000)

	system.stop(coletor)
	system.terminate()
}
