package corescala

import scala.annotation.tailrec

object Soma {

  def somar(lista: List[Int]): Int = {
/*
	lista match {
		case List(_) => lista.head
		case head :: tail => head + somar(tail)
	}
*/
	lista match {
		case Nil => 0
		case head :: tail => head + somar(tail)
	}
  }
}
